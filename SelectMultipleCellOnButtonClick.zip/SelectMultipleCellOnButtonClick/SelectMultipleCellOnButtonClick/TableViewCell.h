//
//  TableViewCell.h
//  SelectMultipleCellOnButtonClick
//
//  Created by Kumar on 13/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *strLabel;

@property (strong, nonatomic) IBOutlet UIButton *checkBoxButton;
@end
