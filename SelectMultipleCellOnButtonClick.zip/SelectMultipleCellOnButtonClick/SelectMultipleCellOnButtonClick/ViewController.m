//
//  ViewController.m
//  SelectMultipleCellOnButtonClick
//
//  Created by Kumar on 13/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

{
    NSMutableArray *arrOfColor;
    NSMutableArray *arrOfSelection;
}
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
- (IBAction)nextView:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    arrOfSelection=[NSMutableArray new];
    arrOfColor=[[NSMutableArray alloc]initWithObjects:@"Red",@"Pink",@"Green",@"Yellow",@"Blue", nil];
    [self allocateSelectedArray];
}

-(void)allocateSelectedArray
{
    for(int i=0;i<[arrOfColor count];i++)
    {
        [arrOfSelection addObject:@"NO"];
    }
    NSLog(@"%@",arrOfSelection);
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrOfColor count];
}
-(TableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell)
    {
        cell=[[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.strLabel.text=[arrOfColor objectAtIndex:indexPath.row];
   
    [cell.checkBoxButton addTarget:self action:@selector(buttonLikeAction:) forControlEvents:UIControlEventTouchUpInside];
    
    if([[arrOfSelection objectAtIndex:indexPath.row]isEqualToString:@"NO"])
    {
         
        [cell.checkBoxButton setImage:[UIImage imageNamed:@"ImageSelectedSmallOff.png"] forState:UIControlStateNormal];
    }
    else
    {
        if([[arrOfSelection objectAtIndex:indexPath.row]isEqualToString:@"YES"])
        {
         [cell.checkBoxButton setImage:[UIImage imageNamed:@"ImageSelectedSmallOn.png"] forState:UIControlStateNormal];
        }
        else
        {
             [cell.checkBoxButton setImage:[UIImage imageNamed:@"ImageSelectedSmallOff.png"] forState:UIControlStateNormal];
        }
    }
      cell.checkBoxButton.tag = indexPath.row;
  
    return cell;
}
-(void)buttonLikeAction:(id)sender
{
    UIButton *button =(UIButton *)sender;
    NSLog(@"%d",button.tag);

    if([[arrOfSelection objectAtIndex:button.tag]isEqualToString:@"NO"])
    {
        [arrOfSelection replaceObjectAtIndex:button.tag withObject:@"YES"];
        NSLog(@"%@",arrOfSelection);
    }
    else
    {
        [arrOfSelection replaceObjectAtIndex:button.tag withObject:@"NO"];
    }
    
    [self.myTableView reloadData];
        
    }
- (IBAction)nextView:(id)sender {
//    UIStoryboard *storyboard=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    NextViewController *nextView=[storyboard instantiateViewControllerWithIdentifier:@"nextView"];
//    [self.navigationController pushViewController:nextView animated:YES];
//    for(int i=0;i<arrOfSelection.count;i++)
//    {
//        if([[arrOfSelection objectAtIndex:i]isEqualToString:@"YES"])
//        {
//            NSString *temp=[arrOfColor objectAtIndex:i];
//            NSLog(@"%@",temp);
//            
//           
//        }
//    }
}
@end
